import asyncio
import pygame
import math
import random
import sys

# ==========================================
# ESTRUCTURAS DE DATOS (LISTA CIRCULAR)
# ==========================================
class Nodo:
    def __init__(self, valor):
        self.valor = valor
        self.siguiente = None

class ListaCircular:
    def __init__(self):
        self.cola = None

    @property
    def cabeza(self):
        if self.cola is None:
            return None
        return self.cola.siguiente

    def esta_vacia(self):
        return self.cola is None

    def insertar_inicio(self, dato):
        nuevo = Nodo(dato)
        if self.cola is None:
            nuevo.siguiente = nuevo
            self.cola = nuevo
        else:
            nuevo.siguiente = self.cola.siguiente
            self.cola.siguiente = nuevo

    def insertar_final(self, dato):
        nuevo = Nodo(dato)
        if self.cola is None:
            nuevo.siguiente = nuevo
            self.cola = nuevo
            return
        nuevo.siguiente = self.cola.siguiente
        self.cola.siguiente = nuevo
        self.cola = nuevo

    def recorrer(self):
        if self.cola is None:
            return []
        resultado = []
        inicio = self.cola.siguiente
        actual = inicio
        while True:
            resultado.append(actual.valor)
            actual = actual.siguiente
            if actual is inicio:
                break
        return resultado

    def contiene(self, buscado):
        if self.cola is None:
            return False
        inicio = self.cola.siguiente
        actual = inicio
        while True:
            if actual.valor == buscado:
                return True
            actual = actual.siguiente
            if actual is inicio:
                break
        return False

    def eliminar_inicio(self):
        if self.cola is None:
            raise IndexError("Vacia")
        cabeza = self.cola.siguiente
        dato = cabeza.valor
        if cabeza is self.cola:
            self.cola = None
        else:
            self.cola.siguiente = cabeza.siguiente
        return dato

    def eliminar(self, buscado):
        if self.cola is None:
            return False
        anterior = self.cola
        actual = self.cola.siguiente
        inicio = actual
        while True:
            if actual.valor == buscado:
                if actual is anterior:
                    self.cola = None
                else:
                    anterior.siguiente = actual.siguiente
                    if actual is self.cola:
                        self.cola = anterior
                return True
            anterior = actual
            actual = actual.siguiente
            if actual is inicio:
                break
        return False


# ==========================================
# CONSTANTES DEL JUEGO
# ==========================================
CARTAS_INFO = {
    'FUEGO': {'color': (220, 50, 50)},
    'AGUA': {'color': (50, 100, 220)},
    'TIERRA': {'color': (101, 67, 33)}, 
    'AIRE': {'color': (150, 100, 200)},
    'RAYO': {'color': (220, 200, 50)}
}

REGLAS_COMBATE = {
    'FUEGO': 'AIRE',
    'AIRE': 'TIERRA',
    'TIERRA': 'RAYO',
    'RAYO': 'AGUA',
    'AGUA': 'FUEGO'
}

COLOR_FONDO = (15, 15, 20)
COLOR_TEXTO = (255, 255, 255)
COLOR_BOTON = (50, 50, 70)
COLOR_BOTON_HOVER = (80, 80, 110)

# ==========================================
# MOTOR DEL JUEGO CON PROYECCIÓN 3D PURA EN PYGAME
# ==========================================
class JuegoCartas3DPygame:
    def __init__(self):
        pygame.init()
        self.ancho = 800
        self.alto = 600
        self.pantalla = pygame.display.set_mode((self.ancho, self.alto))
        pygame.display.set_caption("DUELO DE CARTAS 3D (Sin Ursina)")
        self.reloj = pygame.time.Clock()

        self.font_titulo = pygame.font.SysFont('Arial', 40, bold=True)
        self.font_normal = pygame.font.SysFont('Arial', 24)
        self.font_pequena = pygame.font.SysFont('Arial', 18)

        self.lista_cartas = ListaCircular()
        self.inicializar_lista()
        
        self.vidas_jugador = 3
        self.vidas_rival = 3
        self.puntuacion = 0
        self.ronda = 1
        
        self.estado_actual = "MENU"
        self.nodo_actual_recorrido = None
        
        # Variables de combate
        self.carta_seleccionada = None
        self.carta_rival = None
        self.mensaje_combate = ""
        self.tiempo_resultado = 0
        self.input_admin_texto = "FUEGO"
        self.log_admin = ""
        
        # Variables de cámara 3D
        self.fov = 400
        self.camara_z = -300
        self.rotacion_y = 0.0

        self.botones_menu = [
            ("1. Jugar", (300, 180, 200, 40), self.iniciar_juego, COLOR_BOTON),
            ("2. Ver Lista 3D", (300, 240, 200, 40), self.mostrar_lista_circular, COLOR_BOTON),
            ("3. Administrar", (300, 300, 200, 40), self.mostrar_admin, COLOR_BOTON),
            ("4. Instrucciones", (300, 360, 200, 40), self.mostrar_instrucciones, COLOR_BOTON),
            ("5. Reiniciar", (300, 420, 200, 40), self.reiniciar_partida, COLOR_BOTON),
            ("6. Salir", (300, 480, 200, 40), self.salir, (200, 50, 50))
        ]

    def inicializar_lista(self):
        self.lista_cartas = ListaCircular()
        for tipo in ['FUEGO', 'AGUA', 'TIERRA', 'AIRE', 'RAYO']:
            self.lista_cartas.insertar_final(tipo)

    def salir(self):
        pygame.quit()
        sys.exit()

    def mostrar_menu_principal(self):
        self.estado_actual = "MENU"

    def mostrar_instrucciones(self):
        self.estado_actual = "INSTRUCCIONES"

    def reiniciar_partida(self):
        self.vidas_jugador = 3
        self.vidas_rival = 3
        self.puntuacion = 0
        self.ronda = 1
        self.inicializar_lista()
        self.mostrar_menu_principal()

    def iniciar_juego(self):
        if self.lista_cartas.esta_vacia(): return
        self.estado_actual = "JUGAR"
        self.carta_seleccionada = None
        self.carta_rival = None
        self.mensaje_combate = "Selecciona una carta"

    def mostrar_lista_circular(self):
        self.estado_actual = "LISTA"
        if not self.lista_cartas.esta_vacia():
            self.nodo_actual_recorrido = self.lista_cartas.cabeza

    def mostrar_admin(self):
        self.estado_actual = "ADMIN"
        self.log_admin = ""

    def jugar_ronda(self, tipo_jugador):
        self.carta_seleccionada = tipo_jugador
        self.carta_rival = random.choice(list(CARTAS_INFO.keys()))
        
        if tipo_jugador == self.carta_rival:
            resultado = "EMPATE"
        elif REGLAS_COMBATE.get(tipo_jugador) == self.carta_rival:
            resultado = "¡GANASTE!"
            self.puntuacion += 10
            self.vidas_rival -= 1
        else:
            resultado = "PERDISTE"
            self.vidas_jugador -= 1

        self.mensaje_combate = f"{tipo_jugador} vs {self.carta_rival} -> {resultado}"
        self.ronda += 1
        self.tiempo_resultado = pygame.time.get_ticks()

    def procesar_fin_ronda(self):
        if self.carta_seleccionada and pygame.time.get_ticks() - self.tiempo_resultado > 2500:
            if self.vidas_jugador <= 0 or self.vidas_rival <= 0:
                self.estado_actual = "FIN"
            else:
                self.iniciar_juego()

    # ==========================================
    # SISTEMA DE PROYECCIÓN 3D
    # ==========================================
    def proyeccion_3d(self, x, y, z):
        # Convierte coordenadas 3D a 2D con profundidad
        distancia = z - self.camara_z
        if distancia <= 0: distancia = 1 
        factor = self.fov / distancia
        x_pantalla = self.ancho / 2 + x * factor
        y_pantalla = self.alto / 2 + y * factor
        return x_pantalla, y_pantalla, factor

    def oscurecer_color(self, color, factor_z, max_z):
        # Oscurece el color de la carta según distancia Z
        brillo = max(0.2, min(1.0, 1.5 - (factor_z / max_z)))
        return (int(color[0]*brillo), int(color[1]*brillo), int(color[2]*brillo))

    # ==========================================
    # RENDER
    # ==========================================
    def dibujar_texto(self, texto, font, color, x, y, centrado=False):
        superficie = font.render(texto, True, color)
        rect = superficie.get_rect()
        if centrado: rect.center = (x, y)
        else: rect.topleft = (x, y)
        self.pantalla.blit(superficie, rect)

    def dibujar_boton(self, texto, rect_tup, c_base, c_hover, mouse_pos):
        rect = pygame.Rect(rect_tup)
        color = c_hover if rect.collidepoint(mouse_pos) else c_base
        pygame.draw.rect(self.pantalla, color, rect, border_radius=5)
        self.dibujar_texto(texto, self.font_normal, COLOR_TEXTO, rect.centerx, rect.centery, True)
        return rect

    def render(self):
        self.pantalla.fill(COLOR_FONDO)
        mouse_pos = pygame.mouse.get_pos()

        if self.estado_actual == "MENU":
            self.dibujar_texto("DUELO DE CARTAS: MOTOR 3D PURO", self.font_titulo, (100, 200, 255), self.ancho//2, 80, centrado=True)
            for txt, rect, acc, col in self.botones_menu:
                self.dibujar_boton(txt, rect, col, COLOR_BOTON_HOVER, mouse_pos)

        elif self.estado_actual == "JUGAR":
            self.dibujar_texto(f"Jugador: {'<3'*self.vidas_jugador}", self.font_normal, COLOR_TEXTO, 20, 20)
            self.dibujar_texto(f"Rival: {'<3'*self.vidas_rival}", self.font_normal, COLOR_TEXTO, 650, 20)
            self.dibujar_texto(self.mensaje_combate, self.font_titulo, (255, 200, 50), self.ancho//2, 100, centrado=True)
            self.btn_volver = self.dibujar_boton("Volver", (650, 540, 120, 40), (200,50,50), (255,100,100), mouse_pos)

            if not self.carta_seleccionada:
                cartas_mostrar = self.lista_cartas.recorrer()[:7]
                self.rects_mano = []
                espacio = 120
                inicio_x = -(len(cartas_mostrar)-1) * espacio // 2
                
                objetos_3d = []
                for i, tipo in enumerate(cartas_mostrar):
                    x_3d = inicio_x + i * espacio
                    y_3d = 100
                    z_3d = 0
                    objetos_3d.append({'tipo': tipo, 'x': x_3d, 'y': y_3d, 'z': z_3d, 'index': i})
                
                for obj in objetos_3d:
                    scr_x, scr_y, factor = self.proyeccion_3d(obj['x'], obj['y'], obj['z'])
                    ancho_carta, alto_carta = 100 * factor, 150 * factor
                    
                    rect = pygame.Rect(scr_x - ancho_carta/2, scr_y - alto_carta/2, ancho_carta, alto_carta)
                    hover = rect.collidepoint(mouse_pos)
                    
                    if hover: 
                        scr_y -= 15
                        rect.y -= 15
                    
                    col_base = CARTAS_INFO[obj['tipo']]['color']
                    pygame.draw.rect(self.pantalla, col_base, rect, border_radius=8)
                    pygame.draw.rect(self.pantalla, (255,255,255) if hover else (100,100,100), rect, 3, border_radius=8)
                    self.dibujar_texto(obj['tipo'], self.font_pequena, COLOR_TEXTO, scr_x, scr_y, True)
                    self.rects_mano.append((rect, obj['tipo']))

            else:
                sx_j, sy_j, f_j = self.proyeccion_3d(-150, 0, 0)
                rj = pygame.Rect(sx_j - 100, sy_j - 150, 200, 300)
                pygame.draw.rect(self.pantalla, CARTAS_INFO[self.carta_seleccionada]['color'], rj, border_radius=10)
                self.dibujar_texto(self.carta_seleccionada, self.font_normal, COLOR_TEXTO, sx_j, sy_j, True)
                
                sx_r, sy_r, f_r = self.proyeccion_3d(150, 0, 0)
                rr = pygame.Rect(sx_r - 100, sy_r - 150, 200, 300)
                pygame.draw.rect(self.pantalla, CARTAS_INFO[self.carta_rival]['color'], rr, border_radius=10)
                self.dibujar_texto(self.carta_rival, self.font_normal, COLOR_TEXTO, sx_r, sy_r, True)
                
                self.procesar_fin_ronda()

        elif self.estado_actual == "LISTA":
            self.dibujar_texto("VISTA 3D: CIRCULO CON PROFUNDIDAD", self.font_titulo, (100,200,255), self.ancho//2, 40, True)
            self.dibujar_texto("Teclas: [N] Siguiente | [B] Anterior | [ESC] Menu", self.font_normal, (200,200,200), self.ancho//2, 80, True)
            
            cartas = self.lista_cartas.recorrer()
            if not cartas:
                self.dibujar_texto("Vacio", self.font_titulo, (200,50,50), self.ancho//2, 300, True)
            else:
                num_cartas = len(cartas)
                radio_3d = 300
                self.rotacion_y += 0.01
                
                objetos_3d = []
                for i, tipo in enumerate(cartas):
                    angulo_base = i * (2 * math.pi / num_cartas)
                    angulo_final = angulo_base + self.rotacion_y
                    
                    x_3d = math.cos(angulo_final) * radio_3d
                    z_3d = math.sin(angulo_final) * radio_3d + 200 
                    
                    es_activo = self.nodo_actual_recorrido and self.nodo_actual_recorrido.valor == tipo
                    y_3d = -50 if es_activo else 0 
                    
                    objetos_3d.append({'tipo': tipo, 'x': x_3d, 'y': y_3d, 'z': z_3d, 'activo': es_activo})
                
                # PINTOR ALGORITHM (Pintar de atras hacia adelante)
                objetos_3d.sort(key=lambda obj: obj['z'], reverse=True)
                
                for obj in objetos_3d:
                    scr_x, scr_y, factor = self.proyeccion_3d(obj['x'], obj['y'], obj['z'])
                    ancho_carta, alto_carta = 120 * factor, 180 * factor
                    
                    rect = pygame.Rect(scr_x - ancho_carta/2, scr_y - alto_carta/2, ancho_carta, alto_carta)
                    
                    color_base = CARTAS_INFO[obj['tipo']]['color']
                    color_sombreado = self.oscurecer_color(color_base, obj['z'], radio_3d + 300)
                    
                    pygame.draw.rect(self.pantalla, color_sombreado, rect, border_radius=int(10*factor))
                    borde_col = (0, 255, 0) if obj['activo'] else (200, 200, 200)
                    pygame.draw.rect(self.pantalla, borde_col, rect, int(max(1, 3*factor)), border_radius=int(10*factor))
                    
                    font_dinamica = pygame.font.SysFont('Arial', int(24 * factor), bold=True)
                    self.dibujar_texto(obj['tipo'], font_dinamica, COLOR_TEXTO, scr_x, scr_y, True)

        elif self.estado_actual in ["FIN", "INSTRUCCIONES", "ADMIN"]:
            if self.estado_actual == "ADMIN":
                self.dibujar_texto("ADMINISTRADOR", self.font_titulo, (100,200,255), self.ancho//2, 40, True)
                self.btn_volver = self.dibujar_boton("Volver", (20, 20, 100, 30), (200,50,50), (255,100,100), mouse_pos)
                self.dibujar_texto("Carta a insertar/eliminar:", self.font_normal, COLOR_TEXTO, 100, 120)
                pygame.draw.rect(self.pantalla, (50,50,50), (350, 115, 200, 35))
                self.dibujar_texto(self.input_admin_texto, self.font_normal, (255,255,0), 360, 120)
                
                self.btn_ins_ini = self.dibujar_boton("Insert. Inicio", (100, 180, 150, 40), COLOR_BOTON, COLOR_BOTON_HOVER, mouse_pos)
                self.btn_ins_fin = self.dibujar_boton("Insert. Final", (300, 180, 150, 40), COLOR_BOTON, COLOR_BOTON_HOVER, mouse_pos)
                self.btn_elim_esp = self.dibujar_boton("Eliminar", (500, 180, 150, 40), (200,50,50), (255,100,100), mouse_pos)
                self.dibujar_texto(self.log_admin, self.font_normal, (255,150,150), self.ancho//2, 300, True)
            else:
                self.dibujar_texto("JUEGO TERMINADO / INSTRUCCIONES", self.font_titulo, COLOR_TEXTO, self.ancho//2, 300, True)
                self.btn_volver = self.dibujar_boton("Volver", (300, 500, 200, 40), (200,50,50), (255,100,100), mouse_pos)

        pygame.display.flip()

    def procesar_eventos(self):
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT: self.salir()
            if evento.type == pygame.KEYDOWN:
                if evento.key == pygame.K_ESCAPE: self.mostrar_menu_principal()
                if self.estado_actual == "LISTA" and not self.lista_cartas.esta_vacia():
                    if evento.key == pygame.K_n:
                        self.nodo_actual_recorrido = self.lista_cartas.cabeza if self.nodo_actual_recorrido is None else self.nodo_actual_recorrido.siguiente
                    elif evento.key == pygame.K_b:
                        if self.nodo_actual_recorrido:
                            act = self.lista_cartas.cabeza
                            while act.siguiente is not self.nodo_actual_recorrido: act = act.siguiente
                            self.nodo_actual_recorrido = act
                if self.estado_actual == "ADMIN":
                    if evento.key == pygame.K_BACKSPACE: self.input_admin_texto = self.input_admin_texto[:-1]
                    elif evento.unicode.isalpha(): self.input_admin_texto += evento.unicode.upper()

            if evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                mouse_pos = evento.pos
                if self.estado_actual == "MENU":
                    for txt, rect, acc, col in self.botones_menu:
                        if pygame.Rect(rect).collidepoint(mouse_pos): acc()
                elif self.estado_actual == "JUGAR":
                    if self.btn_volver.collidepoint(mouse_pos): self.mostrar_menu_principal()
                    elif not self.carta_seleccionada:
                        for rect, tipo in self.rects_mano:
                            if rect.collidepoint(mouse_pos): self.jugar_ronda(tipo)
                elif self.estado_actual in ["ADMIN", "INSTRUCCIONES", "FIN"]:
                    if self.btn_volver.collidepoint(mouse_pos): self.mostrar_menu_principal()
                    elif self.estado_actual == "ADMIN":
                        val = self.input_admin_texto.strip()
                        if val in CARTAS_INFO:
                            if self.btn_ins_ini.collidepoint(mouse_pos): self.lista_cartas.insertar_inicio(val); self.log_admin="OK"
                            elif self.btn_ins_fin.collidepoint(mouse_pos): self.lista_cartas.insertar_final(val); self.log_admin="OK"
                            elif self.btn_elim_esp.collidepoint(mouse_pos): self.lista_cartas.eliminar(val); self.log_admin="Eliminado"

    async def run(self):
        while True:
            self.procesar_eventos()
            self.render()
            # Cede el control al navegador para que Pygbag pueda actualizar la pantalla.
            await asyncio.sleep(0)

if __name__ == "__main__":
    juego = JuegoCartas3DPygame()
    asyncio.run(juego.run())
