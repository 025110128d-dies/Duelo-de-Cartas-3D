DUELO DE CARTAS 3D - VERSION WEB

1. Instala Python desde python.org si aún no lo tienes.
2. Abre una terminal en la carpeta que contiene la carpeta duelo_cartas_web.
3. Ejecuta: py -m pip install --upgrade pygbag
4. Ejecuta: py -m pygbag duelo_cartas_web
5. Espera a que termine la preparación y abre http://localhost:8000 en Chrome. La primera carga puede tardar.

IMPORTANTE: Pygbag utiliza pygame-ce para ejecutar Pygame en el navegador. La versión web requiere un ciclo async con await asyncio.sleep(0), ya incorporado en main.py.

Publicación: sigue la guía oficial de GitHub Pages para Pygbag: https://pygame-web.github.io/wiki/publishing/github.io/
